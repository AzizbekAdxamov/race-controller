package com.example.racecontroller

import android.annotation.SuppressLint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okio.ByteString
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity(), SensorEventListener {

    // UI
    private lateinit var authPanel: LinearLayout
    private lateinit var gamePanel: FrameLayout
    private lateinit var statusText: TextView
    private lateinit var speedText: TextView
    private lateinit var speedBar: ProgressBar
    private lateinit var connectBtn: Button
    private lateinit var disconnectBtn: Button
    private lateinit var ipInput: EditText
    private lateinit var nameInput: EditText
    private lateinit var slotInput: EditText
    private lateinit var gasBtn: Button
    private lateinit var brakeBtn: Button

    // Sensors
    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null

    // WebSocket
    private val okHttp = OkHttpClient()
    private var ws: WebSocket? = null
    private var connected = false

    // Control values (sent to server)
    private var throttle = 0.0
    private var brake = 0.0
    private var steer = 0.0

    // Steering tuning
    private val MAX_DEG = 18.0
    private val DEADZONE = 2.5
    private val SMOOTH = 0.22
    private var steerFiltered = 0.0
    private var centerRollDeg = 0.0
    private var currentRollDeg = 0.0

    // Speed HUD (estimated until server sends real speed)
    private var estSpeed = 0.0 // 0..200

    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Bind UI
        authPanel = findViewById(R.id.authPanel)
        gamePanel = findViewById(R.id.gamePanel)
        statusText = findViewById(R.id.statusText)
        speedText = findViewById(R.id.speedText)
        speedBar = findViewById(R.id.speedBar)
        connectBtn = findViewById(R.id.connectBtn)
        disconnectBtn = findViewById(R.id.disconnectBtn)
        ipInput = findViewById(R.id.ipInput)
        nameInput = findViewById(R.id.nameInput)
        slotInput = findViewById(R.id.slotInput)
        gasBtn = findViewById(R.id.gasBtn)
        brakeBtn = findViewById(R.id.brakeBtn)

        // Sensors
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        connectBtn.setOnClickListener { connect() }
        disconnectBtn.setOnClickListener { disconnect() }

        bindHold(gasBtn,
            onDown = { throttle = 1.0; brake = 0.0 },
            onUp = { throttle = 0.0 }
        )
        bindHold(brakeBtn,
            onDown = { brake = 1.0; throttle = 0.0 },
            onUp = { brake = 0.0 }
        )

        setStatus("OFFLINE", good = false)

        // Long-press on SPEED to calibrate center
        speedText.setOnLongClickListener {
            centerRollDeg = currentRollDeg
            Toast.makeText(this, "Center calibrated", Toast.LENGTH_SHORT).show()
            true
        }

        // Main tick: 20Hz send + HUD speed estimate
        ui.post(object : Runnable {
            override fun run() {
                if (connected) {
                    val dt = 0.05
                    estSpeed += 120 * throttle * dt
                    estSpeed -= 220 * brake * dt
                    estSpeed -= 40 * dt
                    estSpeed = clamp(estSpeed, 0.0, 200.0)

                    speedText.text = "${estSpeed.toInt()} km/h"
                    speedBar.progress = estSpeed.toInt()

                    sendInput()
                }
                ui.postDelayed(this, 50)
            }
        })
    }

    private fun setStatus(text: String, good: Boolean) {
        statusText.text = text
        statusText.setTextColor(if (good) 0xFF50DC78.toInt() else 0xFFDC5A5A.toInt())
    }

    private fun showGame() {
        authPanel.visibility = LinearLayout.GONE
        gamePanel.visibility = FrameLayout.VISIBLE
    }

    private fun showAuth() {
        gamePanel.visibility = FrameLayout.GONE
        authPanel.visibility = LinearLayout.VISIBLE
    }

    private fun connect() {
        val ip = ipInput.text.toString().trim()
        val name = nameInput.text.toString().trim().ifEmpty { "PLAYER" }.take(16)
        val slot = slotInput.text.toString().trim().toIntOrNull() ?: 0

        if (ip.isEmpty()) {
            Toast.makeText(this, "PC IP kiriting", Toast.LENGTH_SHORT).show()
            return
        }

        setStatus("CONNECTING…", good = false)

        val req = Request.Builder().url("ws://$ip:8765").build()
        ws = okHttp.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val joinJson = """{"type":"join","name":"$name","preferred_slot":$slot}"""
                webSocket.send(joinJson)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.contains("\"type\":\"joined\"")) {
                    connected = true
                    runOnUiThread {
                        setStatus("ONLINE", good = true)
                        showGame()
                        startSensors()
                    }
                } else if (text.contains("\"type\":\"full\"")) {
                    runOnUiThread {
                        setStatus("OFFLINE", good = false)
                        Toast.makeText(this@MainActivity, "Server full (2 player band)", Toast.LENGTH_SHORT).show()
                    }
                } else if (text.contains("\"type\":\"error\"")) {
                    runOnUiThread {
                        setStatus("OFFLINE", good = false)
                        Toast.makeText(this@MainActivity, "Server error", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {}

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runOnUiThread { disconnectUI() }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread {
                    disconnectUI()
                    Toast.makeText(this@MainActivity, "WS error: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun disconnect() {
        ws?.close(1000, "bye")
        disconnectUI()
    }

    private fun disconnectUI() {
        connected = false
        throttle = 0.0; brake = 0.0; steer = 0.0
        estSpeed = 0.0
        stopSensors()
        setStatus("OFFLINE", good = false)
        showAuth()
    }

    private fun sendInput() {
        val w = ws ?: return
        if (!connected) return
        val json = """{"type":"input","throttle":${fmt(throttle)},"brake":${fmt(brake)},"steer":${fmt(steer)}}"""
        w.send(json)
    }

    // ===== Sensors (Rotation Vector -> Roll -> Steer) =====
    private fun startSensors() {
        val s = rotationSensor
        if (s == null) {
            Toast.makeText(this, "Rotation sensor topilmadi", Toast.LENGTH_SHORT).show()
            return
        }
        sensorManager.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    private fun stopSensors() {
        sensorManager.unregisterListener(this)
        steerFiltered = 0.0
        steer = 0.0
        currentRollDeg = 0.0
        centerRollDeg = 0.0
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!connected) return
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return

        val rotationMatrix = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)

        val orientation = FloatArray(3)
        SensorManager.getOrientation(rotationMatrix, orientation)

        // roll rad -> deg
        val rollDeg = orientation[2].toDouble() * (180.0 / Math.PI)
        currentRollDeg = rollDeg

        var valDeg = rollDeg - centerRollDeg
        if (abs(valDeg) < DEADZONE) valDeg = 0.0

        val raw = clamp(valDeg / MAX_DEG, -1.0, 1.0)
        steerFiltered += (raw - steerFiltered) * SMOOTH
        steer = clamp(steerFiltered, -1.0, 1.0)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    @SuppressLint("ClickableViewAccessibility")
    private fun bindHold(btn: Button, onDown: () -> Unit, onUp: () -> Unit) {
        btn.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { onDown(); true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_UP -> { onUp(); true }
                else -> false
            }
        }
    }

    private fun fmt(v: Double): String = String.format(Locale.US, "%.3f", v)
    private fun clamp(v: Double, a: Double, b: Double): Double = max(a, min(b, v))

    override fun onStop() {
        super.onStop()
        // safety stop
        throttle = 0.0; brake = 0.0; steer = 0.0
        sendInput()
    }
}
